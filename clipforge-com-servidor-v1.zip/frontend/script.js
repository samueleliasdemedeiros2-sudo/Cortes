// Depois de publicar o servidor, coloque aqui a URL dele.
const SERVER_URL = "COLE_A_URL_DO_SERVIDOR_AQUI";

const $ = id => document.getElementById(id);
$("go").onclick = async () => {
  const url = $("url").value.trim();
  if (!url) return $("status").textContent = "Cole o link do YouTube.";

  if (SERVER_URL.includes("COLE_A_URL")) {
    $("status").textContent = "Primeiro coloque a URL do servidor no script.js.";
    return;
  }

  $("go").disabled = true;
  $("status").textContent = "Processando vídeo... isso pode levar alguns minutos.";

  try {
    const r = await fetch(SERVER_URL + "/api/clip", {
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({
        url,
        start:Number($("start").value)||0,
        duration:Number($("duration").value)||60,
        format:$("format").value
      })
    });
    const data = await r.json();
    if (!r.ok) throw new Error(data.error || "Erro no servidor");

    $("video").src = data.clipUrl;
    $("download").href = data.clipUrl;
    $("download").download = "clipforge.mp4";
    $("result").classList.remove("hidden");
    $("status").textContent = "Clip gerado com sucesso.";
    $("result").scrollIntoView({behavior:"smooth"});
  } catch(e) {
    $("status").textContent = "Erro: " + e.message;
  } finally {
    $("go").disabled = false;
  }
};
